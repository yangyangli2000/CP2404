select PAT_FNAME, PAT_LNAME
from patron
order by PAT_LNAME, PAT_FNAME