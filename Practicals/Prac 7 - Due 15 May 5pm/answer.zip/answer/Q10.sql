select BOOK_NUM, BOOK_TITLE, BOOK_COST
from book
order by BOOK_NUM;