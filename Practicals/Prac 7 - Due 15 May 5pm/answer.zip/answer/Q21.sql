select AU_ID, AU_FNAME, AU_LNAME, AU_BIRTHYEAR
from author
order by AU_BIRTHYEAR desc, AU_LNAME;