select BOOK_NUM, BOOK_TITLE AS "TITLE", BOOK_SUBJECT AS "Subject of Book"
from book
order by BOOK_NUM;