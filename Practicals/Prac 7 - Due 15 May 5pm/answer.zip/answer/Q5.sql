select distinct BOOK_YEAR
from BOOK
order by BOOK_YEAR;
