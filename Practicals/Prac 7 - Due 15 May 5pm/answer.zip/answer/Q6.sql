select distinct BOOK_SUBJECT
from BOOK
order by BOOK_SUBJECT;