select BOOK_NUM, BOOK_TITLE, BOOK_COST
from book
where BOOK_COST = 59.95
order by BOOK_NUM;