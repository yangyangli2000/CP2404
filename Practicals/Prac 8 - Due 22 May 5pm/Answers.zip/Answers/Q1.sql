select count(BOOK_NUM) as 'Number of Books'
from book;
