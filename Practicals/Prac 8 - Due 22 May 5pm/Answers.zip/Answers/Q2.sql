select count(distinct(BOOK_SUBJECT)) as 'Number of Subjets'
from book;              