select max(BOOK_COST) AS 'Most Expensive'
FROM BOOK;
