select min(BOOK_COST) as 'Least Expensive'
from book;