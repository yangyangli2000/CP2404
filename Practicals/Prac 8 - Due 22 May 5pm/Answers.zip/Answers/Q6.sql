select sum(BOOK_COST) as 'Library Vaule'
from book;
