select count(distinct(PAT_ID)) as 'DIFFERENT PATRONS'
from checkout;